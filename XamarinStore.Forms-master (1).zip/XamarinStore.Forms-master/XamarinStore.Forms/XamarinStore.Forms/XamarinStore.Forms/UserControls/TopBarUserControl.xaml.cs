﻿namespace XamarinStore.Forms.UserControls
{
	public partial class TopBarUserControl
	{
		public TopBarUserControl()
		{
			InitializeComponent();
		}
	}
}
