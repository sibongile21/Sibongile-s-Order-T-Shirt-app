﻿using Xamarin.Forms;

namespace XamarinStore.Forms.Views
{
	public partial class LoginPage : ContentPage
	{
		public LoginPage()
		{
			InitializeComponent();
		}
	}
}
