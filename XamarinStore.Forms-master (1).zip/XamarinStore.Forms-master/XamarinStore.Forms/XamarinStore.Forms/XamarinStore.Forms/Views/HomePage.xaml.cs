﻿using Xamarin.Forms;
using XamarinStore.Forms.Helpers;

namespace XamarinStore.Forms.Views
{
	public partial class HomePage : ContentPage
	{
		public HomePage()
		{
			InitializeComponent();
		}
	}
}
