﻿using Xamarin.Forms;

namespace XamarinStore.Forms.Views
{
	public partial class ProductDetailsPage : ContentPage
	{
		public ProductDetailsPage()
		{
			InitializeComponent();
		}
	}
}
