﻿using Xamarin.Forms;

namespace XamarinStore.Forms.Views
{
	public partial class OrderSummaryPage : ContentPage
	{
		public OrderSummaryPage()
		{
			InitializeComponent();
		}
	}
}
