﻿using Xamarin.Forms;

namespace XamarinStore.Forms.Views
{
	public partial class ShippingDetailsPage : ContentPage
	{
		public ShippingDetailsPage()
		{
			InitializeComponent();
		}
	}
}
