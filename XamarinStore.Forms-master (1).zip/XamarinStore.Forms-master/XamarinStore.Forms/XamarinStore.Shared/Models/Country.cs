﻿namespace XamarinStore.Forms.Models
{
	public class Country
	{
		public string Code {get;set;}
		public string Name {get;set;}
	}
}

